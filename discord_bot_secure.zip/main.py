import asyncio, logging
from pathlib import Path

import discord
from discord.ext import commands, tasks
from utils_config import load_config, get_token

ROOT = Path(__file__).parent
cfg = load_config()

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")

intents = discord.Intents.all()
bot = commands.Bot(command_prefix=cfg.get("prefix", "wt!"), intents=intents)

INITIAL_EXTENSIONS = [
    "cogs.security",
    "cogs.modtools",
    "cogs.util",
]

@bot.event
async def on_ready():
    try:
        guild_id = cfg.get("guild_id", 0)
        if guild_id:
            guild = discord.Object(id=int(guild_id))
            synced = await bot.tree.sync(guild=guild)
            logging.info(f"Synced {len(synced)} commands to guild {guild_id}")
        else:
            synced = await bot.tree.sync()
            logging.info(f"Globally synced {len(synced)} commands.")
    except Exception as e:
        logging.exception("Slash sync failed: %s", e)
    logging.info(f"Logged in as {bot.user} (ID: {bot.user.id})")

async def load_exts():
    for ext in INITIAL_EXTENSIONS:
        try:
            await bot.load_extension(ext)
            logging.info(f"Loaded {ext}")
        except Exception:
            logging.exception(f"Failed to load {ext}")

def main():
    asyncio.run(load_exts())
    token = get_token()
    bot.run(token)

if __name__ == "__main__":
    main()