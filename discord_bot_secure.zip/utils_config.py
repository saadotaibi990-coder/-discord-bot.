import json
from pathlib import Path
from dotenv import load_dotenv
import os

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")

def load_config():
    with open(ROOT / "config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def get_token():
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        raise RuntimeError("DISCORD_TOKEN مفقود في ملف .env")
    return token