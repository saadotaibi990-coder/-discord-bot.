import discord, aiosqlite, time
from discord import app_commands
from discord.ext import commands
from utils_config import load_config

cfg = load_config()

def is_owner_check():
    async def pred(interaction: discord.Interaction):
        return interaction.user.id in cfg.get("owner_ids", [])
    return app_commands.check(pred)

class ModTools(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="ban", description="حظر عضو")
    @app_commands.checks.has_permissions(ban_members=True)
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str="لا يوجد سبب"):
        await member.ban(reason=reason)
        await interaction.response.send_message(f"تم حظر {member} | السبب: {reason}", ephemeral=False)

    @app_commands.command(name="lockdown", description="قفل السيرفر (للمدير)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def lockdown(self, interaction: discord.Interaction, minutes: int=10):
        guild = interaction.guild
        for ch in guild.text_channels:
            try:
                await ch.set_permissions(guild.default_role, send_messages=False)
            except Exception:
                pass
        await interaction.response.send_message(f"تم قفل السيرفر لمدة {minutes} دقيقة.")
        await discord.utils.sleep_until(discord.utils.utcnow() + discord.timedelta(minutes=minutes))
        for ch in guild.text_channels:
            try:
                await ch.set_permissions(guild.default_role, send_messages=True)
            except Exception:
                pass

async def setup(bot):
    await bot.add_cog(ModTools(bot))