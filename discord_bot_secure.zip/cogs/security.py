import re, discord, asyncio, aiosqlite, time
from collections import defaultdict, deque
from discord.ext import commands, tasks
from discord import app_commands
from utils_config import load_config

cfg = load_config()
INVITE_REGEX = re.compile(r"(?:discord\.gg|discord(?:app)?\.com/invite)/\w+", re.IGNORECASE)
URL_REGEX = re.compile(r"https?://\S+", re.IGNORECASE)

class Security(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.msg_cache = defaultdict(lambda: deque())  # user_id -> timestamps
        self.join_cache = deque()  # timestamps of recent joins
        self.protection_enabled = True
        self.db_path = "data/security.sqlite3"
        bot.loop.create_task(self.init_db())

    async def init_db(self):
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""CREATE TABLE IF NOT EXISTS infractions(
                guild_id INTEGER, user_id INTEGER, type TEXT, reason TEXT, ts INTEGER
            )""")
            await db.commit()

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return
        # invite block
        if cfg.get("block_invite_links", True) and INVITE_REGEX.search(message.content):
            try:
                await message.delete()
            except Exception:
                pass
            await message.channel.send(f"🚫 يمنع نشر روابط الدعوات {message.author.mention}", delete_after=6)
            await self.log_infraction(message.guild.id, message.author.id, "invite", "Posted invite link")
            return

        # external link block (if enabled)
        if cfg.get("block_external_links", False) and URL_REGEX.search(message.content):
            try:
                await message.delete()
            except Exception:
                pass
            await message.channel.send(f"🚫 يمنع نشر روابط خارجية {message.author.mention}", delete_after=6)
            await self.log_infraction(message.guild.id, message.author.id, "link", "Posted external link")
            return

        # file extension check
        for att in message.attachments:
            fn = att.filename.lower()
            for ext in cfg.get("banned_file_extensions", []):
                if fn.endswith(ext):
                    try:
                        await message.delete()
                    except Exception:
                        pass
                    await message.channel.send(f"🚫 نوع ملف ممنوع {message.author.mention}", delete_after=6)
                    await self.log_infraction(message.guild.id, message.author.id, "file", f"Uploaded {ext}")
                    return

        # anti-spam simple (messages in timeframe)
        as_cfg = cfg.get("anti_spam", {})
        thr = as_cfg.get("messages_threshold", 6)
        per = as_cfg.get("per_seconds", 6)
        now = time.time()
        dq = self.msg_cache[message.author.id]
        dq.append(now)
        # drop old
        while dq and now - dq[0] > per:
            dq.popleft()
        if len(dq) >= thr:
            # mute: try to add timeout (discord.py 2.6+)
            try:
                await message.author.timeout_for(seconds=as_cfg.get("mute_minutes", 5)*60)
            except Exception:
                pass
            await message.channel.send(f"🚫 {message.author.mention} تم كتمه مؤقتًا بسبب السبام", delete_after=6)
            await self.log_infraction(message.guild.id, message.author.id, "spam", "Spam detected")
            dq.clear()
            return

    async def log_infraction(self, guild_id, user_id, itype, reason):
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("INSERT INTO infractions VALUES (?,?,?, ?, ?)", (guild_id, user_id, itype, reason, int(time.time())))
            await db.commit()

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        # anti-raid: detect many joins in short time
        now = time.time()
        self.join_cache.append(now)
        per = cfg.get("anti_raid", {}).get("per_seconds", 10)
        thr = cfg.get("anti_raid", {}).get("join_threshold", 6)
        # drop old
        while self.join_cache and now - self.join_cache[0] > per:
            self.join_cache.popleft()
        if len(self.join_cache) >= thr:
            # lockdown: remove send perms for @everyone
            guild = member.guild
            for ch in guild.text_channels:
                try:
                    await ch.set_permissions(guild.default_role, send_messages=False)
                except Exception:
                    pass
            # log to mod channel if available
            log_id = cfg.get("log_channel_id", 0)
            if log_id:
                ch = guild.get_channel(int(log_id))
                if ch:
                    await ch.send("🚨 نظام الدفاع: تم اكتشاف هجوم انضمام جماعي، السيرفر تحت قفل مؤقت.")
            # schedule unlock
            asyncio.create_task(self._unlock_after(guild, cfg.get("anti_raid", {}).get("lockdown_minutes", 10)))
    
    async def _unlock_after(self, guild, minutes):
        await asyncio.sleep(minutes*60)
        for ch in guild.text_channels:
            try:
                await ch.set_permissions(guild.default_role, send_messages=True)
            except Exception:
                pass

    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role):
        if not cfg.get("protect_roles", True):
            return
        # role creation protection: revoke role if created by non-admin? we'll notify
        audit = None
        try:
            async for entry in role.guild.audit_logs(limit=1, action=discord.AuditLogAction.role_create):
                audit = entry
                break
        except Exception:
            pass
        if audit and audit.user and not audit.user.guild_permissions.manage_roles:
            # attempt to delete the role
            try:
                await role.delete()
            except Exception:
                pass
            ch = role.guild.get_channel(cfg.get("log_channel_id", 0))
            if ch:
                await ch.send(f"🔒 محاولة إنشاء رتبة من قبل {audit.user.mention} تم إزالتها (حماية الرتب).")

async def setup(bot):
    await bot.add_cog(Security(bot))